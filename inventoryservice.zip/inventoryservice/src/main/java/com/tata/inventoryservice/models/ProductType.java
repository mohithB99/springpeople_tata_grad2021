package com.tata.inventoryservice.models;

public enum ProductType {
 Electronics,Furniture,Garments,HomeAppliances
}
