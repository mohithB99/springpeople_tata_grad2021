package com.formento.aop.service;

import com.formento.aop.model.Product;

public interface ProductService {

    Product create(final Product product);

}
