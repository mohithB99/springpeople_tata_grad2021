package com.formento.aop.aspect;

import com.formento.aop.model.Product;

public interface ProductCreationAspect {

    void validate(Product product);

}
