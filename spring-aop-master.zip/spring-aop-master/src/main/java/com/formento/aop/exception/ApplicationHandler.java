package com.formento.aop.exception;

public interface ApplicationHandler {
}
