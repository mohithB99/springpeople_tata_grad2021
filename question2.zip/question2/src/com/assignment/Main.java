package com.assignment;


	// write your code here
        class worker
        {
            String name;
            int empno;
            worker(int no,String n)
            { empno=no; name=n; }
            void show()
            {
                System.out.println("\n--------------------------");
                System.out.println("Employee number : "+empno);
                System.out.println("Employee name : "+name);
            }
        }
        class dworker extends worker
        {
            int rate;
            dworker(int no,String n,int r)
            {
                super(no,n);
                rate=r;
            }
            void compay(int h)
            {
                show();
                System.out.println("Salary : "+rate*h);
            }
        }
        class sdworker extends worker
        {
            int rate;
            sdworker(int no,String n,int r)
            {
                super(no,n);
                rate=r;
            }
            int hour=40;
            void compay()
            {
                show();
                System.out.println("Salary : "+rate*hour);
            }
        }


            public class Main{
            public static void main(String args[])
            {
                dworker d=new dworker(254,"Arjun",75);
                sdworker s=new sdworker(666,"Unni",100);
                d.compay(45);
                s.compay();
            }
        }



