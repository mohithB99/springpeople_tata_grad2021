package com.tata.Assignment2.dao;

import com.tata.Assignment2.models.CD;

import java.util.List;

public interface sortI {
    List<CD> getAllDetails();

}