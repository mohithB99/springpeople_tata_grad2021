package com.tata.Assignment2.business;

import com.tata.Assignment2.models.CD;

import java.util.Comparator;

public class CdSorter implements Comparator<CD> {
    @Override
    public int compare(CD a, CD b)
    {
        return a.getSinger().compareTo(b.getSinger());
    }
}


