package com.tata.Assignment2.utility;

import com.tata.Assignment2.business.CdSorter;
import com.tata.Assignment2.dao.sortI;
import com.tata.Assignment2.dao.sortImpl;
import com.tata.Assignment2.models.CD;

import java.util.Collections;
import java.util.List;

public class CDApp {
    public static void main(String[] args)
    {

        sortI s = new sortImpl();
        List<CD> li = s.getAllDetails();
        System.out.println("Before Sorting: ");
        for(CD cd: li)
        {
            System.out.println(cd.getSinger() +" "+ cd.getTitle());
        }
        //System.out.println(li);
        Collections.sort(li,new CdSorter());
        System.out.println("After Sorting: ");
        for(CD cd: li) {
            System.out.println(cd.getSinger() + " " + cd.getTitle());
        }

    }
}