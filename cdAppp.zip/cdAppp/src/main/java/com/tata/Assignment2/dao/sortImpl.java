package com.tata.Assignment2.dao;

import com.tata.Assignment2.models.CD;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class sortImpl implements sortI {
    Scanner sc = new Scanner(System.in);
    @Override
    public List<CD> getAllDetails()
    {
        return getData();
    }
    public List<CD> getData()
    {
        List<CD> l = new ArrayList<>();
        CD te = null;
        for(int i=0;i<2;i++)
        {
            te = new CD();
            System.out.println("Enter Singer Name: ");
            te.setSinger(sc.next());
            System.out.println("Enter Singer Title: ");
            te.setTitle(sc.next());
            l.add(te);
        }
        return l;
    }
}