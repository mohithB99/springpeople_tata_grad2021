package com.tata.Assignment2.tests;

import com.tata.Assignment2.business.CdSorter;
import com.tata.Assignment2.dao.sortI;
import com.tata.Assignment2.dao.sortImpl;
import com.tata.Assignment2.models.CD;
import com.tata.Assignment2.utility.CDApp;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

public class SingerTest {
    private CD cd1,cd2;
    private CdSorter cdS1,cdS2;
    private sortI dao1,dao2;
    private CDApp cdApp1,cdApp2;
    @BeforeEach
    public void getInstance()
    {
        cd1 = new CD();
        cd2 = new CD();
        cd1.setSinger("Arjit");
        cd1.setTitle("Rock");
        cd2.setSinger("Atif");
        cd2.setTitle("Melody");
        cdS1 =new CdSorter();
        cdS2 = new CdSorter();
        dao1 = new sortImpl();
        dao2= new sortImpl();
        cdApp1 = new CDApp();
        cdApp2= new CDApp();
    }
    @Test
    @DisplayName("Title name should not be same")
    public void titleNameNotSame()
    {
        assertNotEquals(cd1.getTitle(),cd2.getTitle());
    }

    @Test
    @DisplayName("Singer name should not be same")
    public void singerNameNotSame()
    {
        assertNotEquals(cd1.getSinger(),cd2.getSinger());
    }

    @ParameterizedTest
    @ValueSource(strings = {"Mohith","Rohith","Naveen","Vamsi"})
    public void titleNameLengthNotMoreThan20(String title)
    {
        cd1.setTitle(title);
        assertTrue(cd1.getTitle().length()<=20);
    }

    @RepeatedTest(10)
    void repeatedTestWithRepetitionInfo(RepetitionInfo repetitionInfo) {
        assertEquals(10, repetitionInfo.getTotalRepetitions());
        assertEquals(cdS1.compare(cd1,cd2),cdS2.compare(cd1,cd2));
    }

    @Test
    public void dataNotSame()
    {
        assertNotEquals(dao1.getAllDetails(),dao2.getAllDetails());
    }

    @Test
    public void singerNameShouldNotBeNull()
    {
        assertThrows(NullPointerException.class,()->{cd1.getSinger();});
    }

    @Test
    public void titleNameShouldNotBeNull()
    {
         assertThrows(NullPointerException.class,()->{cd2.getTitle();});
    }

    @Test
    public void infoNotSame()
    {
        assertEquals(cdS1.compare(cd1,cd2),cdS2.compare(cd1,cd2));
    }

    @ParameterizedTest
    @CsvFileSource(resources = "cdData.csv", numLinesToSkip = 1)
    void testWithCsvFileSource(String title, String singer) {
        assertTrue(title.length()>0);
        assertFalse(title.length()>20);
    }
}

