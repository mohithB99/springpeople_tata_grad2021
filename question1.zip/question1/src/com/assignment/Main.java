package com.assignment;
import java.util.*;
public class Main {

            public static void main(String[] args){
                Scanner sc = new Scanner(System.in);
                float totalPrice= 0;
                while(true)
                {
                    String s  =sc.nextLine();

                    if(s.equals("end"))
                        break;

                    String s1=sc.nextLine();

                    int p_id = Integer.parseInt(s);
                    int qty = Integer.parseInt(s1);
                    switch(p_id) {
                        case 1:
                            totalPrice += (float) qty * 22.5f;
                            break;
                        case 2:
                            totalPrice += (float) qty * 44.5f;
                            break;
                        case 3:
                            totalPrice += (float) qty * 9.98f;
                            break;
                    }
                }
                System.out.println(totalPrice);
            }
        }



        // write your code here


