package com.tata.webstoreapp.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name="TataUserAddress")
@Data
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="AddressId")
    private int addressId;
    @ApiModelProperty(example = "8d")
    @Column(name="DoorNo")
    private String doorNo;
    @ApiModelProperty(example = "Rajaji Street")
    @Column(name="StreetName")
    private String streetName;
    @ApiModelProperty(example = "Chennai")
    @Column(name="City")
    private String city;
    @ApiModelProperty(example = "TamilNadu")
    @Column(name="State")
    private String state;
    @ApiModelProperty(example = "600049")
    @Column(name="Pincode")
    private long pinCode;
    @ManyToOne
    @JoinColumn(foreignKey = @ForeignKey(name = "UserId"), name = "UserId")
    @JsonIgnore
    private UserAccount userAccount;

}
