package com.tata.storeapp.models;

import lombok.Data;

@Data
public class Category {

    private String name;
}
