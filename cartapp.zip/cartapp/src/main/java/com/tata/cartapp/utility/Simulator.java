package com.tata.cartapp.utility;

import com.tata.cartapp.models.Vehicle;

import java.util.Random;

public class Simulator {

    public static void main(String[] args){

        //create 5 threads
        Vehicle[] vehicles=new Vehicle[5];
        for(int i=0;i<5;i++){
            vehicles[i]=new Vehicle("TN-32"+new Random().nextInt(100000));
            vehicles[i].start();
            vehicles[i].randomWait();
        }

    }
}
