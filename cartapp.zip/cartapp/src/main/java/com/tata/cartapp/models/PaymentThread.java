package com.tata.cartapp.models;

public class PaymentThread implements Runnable{


    @Override
    public void run() {

        System.out.println(Thread.currentThread().getName()+","+Thread.currentThread().getPriority());

    }
}
