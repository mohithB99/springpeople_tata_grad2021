package com.tata.cartapp.utility;

import com.tata.cartapp.models.ManufacturerConsumer;

public class InterThreadCommn {
    public static  void main(String[] args){

        ManufacturerConsumer mc=new ManufacturerConsumer();
        Thread t1 =new Thread(mc,"Supplier");
        Thread t2=new Thread(mc,"Consumer");
        t1.start();
        t2.start();

    }
}
