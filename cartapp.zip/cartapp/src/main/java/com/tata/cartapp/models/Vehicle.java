package com.tata.cartapp.models;

import java.util.Random;

public class Vehicle extends Thread{
    private TollBooth tollBooth;
    private Bridge bridge;
    private String vehicleNo;
    public Vehicle(String regNo){
        this.vehicleNo=regNo;
        this.tollBooth=new TollBooth();
        this.bridge=new Bridge();
    }

    @Override
    public void run() {
        //critical Methods
     this.bridge.bridgeMessage(this.vehicleNo);
     this.tollBooth.tollBoothMessage(this.vehicleNo);
    }

    public void randomWait(){
        try {
            Thread.sleep(new Random().nextInt(10000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
