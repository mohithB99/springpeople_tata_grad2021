package com.tata.cartapp.utility;

import com.tata.cartapp.models.PaymentThread;

import java.util.ArrayList;
import java.util.List;

public class EcommerceApp {

    public static void main(String[] args)  {


        Thread[] thread=new Thread[10];
        for(int i=0;i<10;i++) {
            thread[i] = new Thread(new PaymentThread(), "Payment-Thread "+i);
            thread[i].start();
            if(i==5)
                thread[i].setPriority(10);
            try {
                thread[i].join();
            }
            catch(InterruptedException ex)
            {

            }
        }

        System.out.println(Thread.currentThread().getName()+","+Thread.currentThread().getPriority());
    }
}
