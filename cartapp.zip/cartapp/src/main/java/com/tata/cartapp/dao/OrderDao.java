package com.tata.cartapp.dao;

import com.tata.cartapp.models.Cart;
import com.tata.cartapp.models.Order;

import java.util.Hashtable;

public interface OrderDao {

    void bookOrder(Cart cart);
    Hashtable<Order,Cart> viewOrders();
    void cancelOrder(long orderId);
}
