package com.tata.cartapp.dao;


import com.tata.cartapp.models.Cart;
import com.tata.cartapp.models.Order;

import java.time.LocalDate;
import java.util.Hashtable;
import java.util.Map;
import java.util.Random;

public class OrderImpl implements OrderDao {
    private Hashtable<Order,Cart> orders;

    public OrderImpl(){
        orders=new Hashtable<Order,Cart>();
    }
    @Override
    public void bookOrder(Cart cart) {
        orders.put(new Order(new Random().nextInt(), LocalDate.now()),cart);

    }

    @Override
    public Hashtable<Order, Cart> viewOrders() {
        return orders;
    }

    @Override
    public void cancelOrder(long orderId) {

       Order order= orders.keySet().stream().filter(o->o.getOrderId()==orderId)
               .findFirst().orElse(null);
       orders.remove(order);

    }
}
