package com.tata.cartapp.dao;

import com.tata.cartapp.models.Product;

import java.util.ArrayList;
import java.util.List;

public class CartImpl implements CartDao{
    private List<Product> productList;

    public CartImpl(){
        productList=new ArrayList<Product>();
    }

    @Override
    public void addProduct(Product product) {
        productList.add(product);
    }

    @Override
    public void removeProduct(long productId) {
      Product product=productList.stream()
              .filter(p->p.getProductId()==productId)
              .findFirst().orElse(null);
     productList.remove(product);
    }

    @Override
    public List<Product> viewProducts() {
        return productList;
    }
}
