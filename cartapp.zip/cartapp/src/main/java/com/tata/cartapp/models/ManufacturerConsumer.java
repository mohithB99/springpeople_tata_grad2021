package com.tata.cartapp.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ManufacturerConsumer implements  Runnable {
    private List<Product> productList;
    public ManufacturerConsumer(){
        productList=new ArrayList<Product>();
    }
    public synchronized void supplier(){
     while(true) {
         if (productList.size() == 0) {

             System.out.println("Manufacturer Producing.....");
             for (int i = 0; i < 10; i++) {
                 productList.add(new Product(i, "product" + i,
                         new Random().nextInt(10000)));
             }
             try {
                 Thread.sleep(2000);
             } catch (InterruptedException e) {
                 e.printStackTrace();
             }
             notify();

         } else {
             System.out.println("Supplier is in waiting state");
             try {
                 wait();
             } catch (InterruptedException e) {
                 e.printStackTrace();
             }

         }
     }

    }

    public synchronized  void consumer(){
      while(true) {
          if (productList.size() > 0) {
              System.out.println("Consumer consuming....");
              for (Product product : productList) {
                  System.out.println(product);
              }
              productList = new ArrayList<Product>();
              try {
                  Thread.sleep(2000);
              } catch (InterruptedException e) {
                  e.printStackTrace();
              }
              notify();
          } else {
              System.out.println("Consumer is in waiting state");
              try {
                  wait();
              } catch (InterruptedException e) {
                  e.printStackTrace();
              }

          }
      }

    }


    @Override
    public void run() {

        if(Thread.currentThread().getName().equals("Supplier"))
            supplier();
        else
            consumer();


    }
}
