package com.tata.cartapp.models;

import java.time.LocalDate;

public class TollBooth {

    public void tollBoothMessage(String vehicleNo) {
        synchronized (this) {
            System.out.println(vehicleNo
                    + " crossed the tollbooth @" + LocalDate.now());
        }
    }
}
