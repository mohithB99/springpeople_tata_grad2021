package com.tata.cartapp.models;

import java.time.LocalDate;

public class Bridge {

    public void bridgeMessage(String vehicleNo){
        synchronized (this){
            System.out.println(vehicleNo
                    +" crossed the bridge @"+ LocalDate.now());
        }
    }
}
