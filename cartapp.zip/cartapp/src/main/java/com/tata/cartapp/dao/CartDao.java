package com.tata.cartapp.dao;

import com.tata.cartapp.models.Product;

import java.util.List;

public interface CartDao {

    void addProduct(Product product);
    void removeProduct(long ProductId);
    List<Product> viewProducts();

}
