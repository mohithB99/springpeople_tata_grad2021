package com.tata.cartapp.utility;

import com.tata.cartapp.dao.CartDao;
import com.tata.cartapp.dao.CartImpl;
import com.tata.cartapp.dao.OrderDao;
import com.tata.cartapp.dao.OrderImpl;
import com.tata.cartapp.models.Cart;
import com.tata.cartapp.models.Product;

import java.util.Iterator;
import java.util.Map;
import java.util.Random;

public class BillingApp {
    public static  void main(String... args){
      System.out.println(Thread.currentThread().getName());
        OrderDao orderDao=new OrderImpl();
        for(int i=0;i<5;i++) {
            orderDao.bookOrder(createCart());
        }
        //visualize
       orderDao.viewOrders().entrySet().stream()
               //.map(Map.Entry::getValue)
               .forEach(System.out::println);


    }

    private static Cart createCart(){

        CartDao cartDao=new CartImpl();
        Product product=null;
        for(int i=0;i<5;i++){
           product=new Product(i,"product"+i,
                   new Random().nextInt(10000));
           cartDao.addProduct(product);
        }
        Cart cart =new Cart();
        cart.setCartNo(new Random().nextInt(10000));
        cart.setProductList(cartDao.viewProducts());
        return cart;

    }

}
