package com.everyday.models;

public enum Material {
    Cotton,Woolen
}
