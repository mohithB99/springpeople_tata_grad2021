package employee.models;

public class SalariedWorker extends Worker{
    @Override
    public int pay(int hrs)
    {
        return hrs*this.getSalary();
    }
}
