package employee.models;

public class DailyWorker extends Worker{
    @Override
    public int pay(int hrs)
    {
        return hrs*this.getSalary();
    }
}
