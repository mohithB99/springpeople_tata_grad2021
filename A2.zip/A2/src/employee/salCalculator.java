package employee;
import employee.models.*;
import java.util.*;
public class salCalculator {
    public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		DailyWorker d = new DailyWorker();
		System.out.println("Enter name of Daily employee: ");
		d.setName(sc.next());
		System.out.println("Enter salary: ");
		d.setSalary(sc.nextInt());
		System.out.println("Enter number of hours: ");
		System.out.println("Salary is " + d.pay(sc.nextInt()));


		SalariedWorker s = new SalariedWorker();
		System.out.println("Enter name of Salaried employee: ");
		s.setName(sc.next());
		System.out.println("Enter salary: ");
		s.setSalary(sc.nextInt());
		System.out.println("Salary is " + s.pay(40));
    }
}
