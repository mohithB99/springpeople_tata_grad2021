package com.tata.assignOne;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Product Number: ");
        int productNumber, quantitySold, totalProducts=0;
        double totalValue = 0;
        productNumber = sc.nextInt();
        do{
            totalProducts++;
            System.out.print("Enter Quantity Sold: ");
            quantitySold = sc.nextInt();
            switch(productNumber){
                case 1:
                    totalValue+=(quantitySold*22.50);
                    break;
                case 2:
                    totalValue+=(quantitySold*44.50);
                    break;
                case 3:
                    totalValue+=(quantitySold*9.98);
                    break;
                default:
                    totalProducts--;
                    System.out.println("Wrong Product Number Entered!");
            }
            System.out.print("Enter Product Number(0 for exit): ");
            productNumber = sc.nextInt();
        } while(productNumber!=0);
        System.out.println("Total Retail Value of "+totalProducts+" Products: "+totalValue);
    }
}
