package com.tata.assignTwo;

public class SalariedWorker extends Worker {
    private double salaryRate;
    private int hours;

    public double getSalaryRate() {
        return salaryRate;
    }

    public void setSalaryRate(double salaryRate) {
        this.salaryRate = salaryRate;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    double Pay (int hours){
        return salaryRate*40;
    }
}
