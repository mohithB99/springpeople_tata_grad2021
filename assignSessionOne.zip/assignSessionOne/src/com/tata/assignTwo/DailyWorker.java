package com.tata.assignTwo;

public class DailyWorker extends Worker {
    private double salaryRate;
    private int days;

    public double getSalaryRate() {
        return salaryRate;
    }

    public void setSalaryRate(double salaryRate) {
        this.salaryRate = salaryRate;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    double Pay(int day){
        return salaryRate*day;
    }
}
