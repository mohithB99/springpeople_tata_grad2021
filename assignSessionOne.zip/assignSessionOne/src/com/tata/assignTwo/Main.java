package com.tata.assignTwo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Type of Worker (1 for daily | 2 for salaried): ");
        int option = sc.nextInt();
        if(option==1) {
            DailyWorker daily = new DailyWorker();
            System.out.print("Enter Name of Worker: ");
            daily.setName(sc.next());
            daily.setWorkerId(1);
            System.out.print("Enter Salary Rate: ");
            daily.setSalaryRate(sc.nextDouble());
            System.out.print("Enter Number of Working Days: ");
            daily.setDays(sc.nextInt());
            System.out.print("Total Wage Paid to Daily Worker: "+daily.Pay(daily.getDays()));
        }
        else {
            SalariedWorker salaried = new SalariedWorker();
            System.out.print("Enter Name of Worker: ");
            salaried.setName(sc.next());
            salaried.setWorkerId(2);
            System.out.print("Enter Salary Rate: ");
            salaried.setSalaryRate(sc.nextDouble());
            System.out.print("Enter Number of Working Hours: ");
            salaried.setHours(sc.nextInt());
            System.out.print("Total Wage Paid to Salaried Worker: "+salaried.Pay(salaried.getHours()));
        }
    }
}
