package com.tata.shippingservice.repositories;

import java.util.List;


import com.tata.shippingservice.models.StockStatusHistory;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;


public interface ShippingRepository extends MongoRepository<StockStatusHistory,Long>{

	
	
}
