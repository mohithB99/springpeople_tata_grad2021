package com.tata.shoppingden.models;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "TataProduct")
@Data
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ProductId")
    private int productId;
    @Column(name = "ProductName")
    private String productName;
    @Column(name = "DOP")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dop;
    @Column(name = "Cost")
    private int cost;
    @Column(name = "AvailableQty")
    private int availableQty;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(foreignKey = @ForeignKey(name = "CategoryId"), name = "CategoryId")
    private Category category;

}
