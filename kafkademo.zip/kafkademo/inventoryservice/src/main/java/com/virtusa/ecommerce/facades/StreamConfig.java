package com.virtusa.ecommerce.facades;

import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(InventoryStreams.class)
public class StreamConfig {
}
