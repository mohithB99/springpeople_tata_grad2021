import java.util.*;
public class Main {
    public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
        float totalPrice= 0;
	    while(true)
        {
            System.out.println("Enter ProductID and Quantity with space in line: ");
            String s =sc.nextLine();
            if(s.equals("end"))
                break;
            String[] n= s.split(" ");
            int p_id = Integer.parseInt(n[0]);
            int qty = Integer.parseInt(n[1]);
            switch(p_id) {
                case 1:
                    totalPrice += (float) qty * 22.5f;
                    break;
                case 2:
                    totalPrice += (float) qty * 44.5f;
                    break;
                case 3:
                    totalPrice += (float) qty * 9.98f;
                    break;
            }
        }
	    System.out.println(totalPrice);
    }
}
